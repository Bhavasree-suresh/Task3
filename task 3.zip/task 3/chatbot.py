import nltk
from nltk.chat.util import Chat, reflections

pairs = [
    [
        r"hi|hello|hey",
        ["Hello!", "Hi there!", "Hey! How can I help you?"]
    ],
    [
        r"what is your name?",
        ["I am a chatbot created by Niranjana."]
    ],
    [
        r"how are you ?",
        ["I'm good, thank you!", "Doing great!"]
    ],
    [
        r"bye",
        ["Goodbye!", "See you later!"]
    ],
    [
        r"(.*)",
        ["I'm not sure I understand. Can you rephrase that?"]
    ]
]

def chatbot():
    print("Hi! I’m your AI Bot. Type 'bye' to exit.")
    chat = Chat(pairs, reflections)
    chat.converse()

chatbot()
